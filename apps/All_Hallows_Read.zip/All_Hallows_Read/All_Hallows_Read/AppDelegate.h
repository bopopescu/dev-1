//
//  AppDelegate.h
//  All_Hallows_Read
//
//  Created by Samuel Svenningsen on 10/17/14.
//  Copyright (c) 2014 Sam Svenningsen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

