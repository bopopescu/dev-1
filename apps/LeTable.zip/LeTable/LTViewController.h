//
//  LTViewController.h
//  LeTable
//
//  Created by Tim Novikoff on 9/13/14.
//  Copyright (c) 2014 Tim Novikoff. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LTViewController : UIViewController

@end
