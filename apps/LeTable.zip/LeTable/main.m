//
//  main.m
//  LeTable
//
//  Created by Tim Novikoff on 9/13/14.
//  Copyright (c) 2014 Tim Novikoff. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LTAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LTAppDelegate class]));
    }
}
