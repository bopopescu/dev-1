//
//  main.m
//  PortManteau
//
//  Created by Samuel Svenningsen on 9/7/14.
//  Copyright (c) 2014 Sam Svenningsen. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PMAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PMAppDelegate class]));
    }
}
